from .location_serializer import LocationSerializer
